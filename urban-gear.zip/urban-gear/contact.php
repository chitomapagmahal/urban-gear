<?php $TITLE = "Contact Us"; ?>

<?php include('header.php') ?>

<?php

    $SQL = "SELECT * FROM `users` WHERE `id`='". $_SESSION['login_id'] ."' ";
    $RESULT = mysqli_query($CONN, $SQL);

    while ($USER_DETAILS = mysqli_fetch_array($RESULT))
    {
        $MY_ACCOUNT_EMAIL = $USER_DETAILS['email'];
        $MY_ACCOUNT_USERNAME = $USER_DETAILS['username'];
        $MY_ACCOUNT_PASSWORD = $USER_DETAILS['password'];
    }

?>

</div>
<!-- End Search, etc -->

<div id="content">

    <div id="container">

        <div id="tabbed">

            <div class="about_boxing-prop">

                <?php if (isset($_SESSION['alert-type'])): ?>

                <p class="<?php echo $ALERT_TYPE ?>"><?php echo $_SESSION['message'] ?></p>

                <?php unset($_SESSION['alert-type']); ?>

                <?php endif; ?>

                <div class="about_about-section">
                    
                    <h1>Contact Us</h1>
                    
                </div>

                <br>

                <hr class="update_hr">

                <br>

                <div class="contact_container">
                    
                    <form action="" method="POST">
    
                        <label for="email">Email</label>
                        <input class="contact_input" type="text" id="email" name="contact_email" value="<?php echo $MY_ACCOUNT_EMAIL ?>" readonly>

                        <label for="username">Username</label>
                        <input class="contact_input" type="text" id="username" name="contact_username" value="<?php echo $MY_ACCOUNT_USERNAME ?>" readonly>
        
                        <label for="message">Message</label>
                        <textarea class="contact_input" id="message" name="contact_message" placeholder="Your message here.." style="height:200px" required></textarea>

                        <input class="contact_submit_btn" type="submit" value="Submit" name="contact">
  
                    </form>

                </div>

<?php include('footer.php'); ?>