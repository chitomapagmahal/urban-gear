-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 28, 2021 at 08:32 PM
-- Server version: 8.0.13-4
-- PHP Version: 7.2.24-0ubuntu0.18.04.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urban_gear`
--

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE `cards` (
  `id` int(11) NOT NULL,
  `card_owner` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `card_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiration_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cvc_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `credit_value` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cards`
--

INSERT INTO `cards` (`id`, `card_owner`, `card_number`, `expiration_date`, `cvc_code`, `credit_value`) VALUES
(1, 'Carlo Phillip Anteja', '2222400070000005', '03/2030', '737', 95102),
(2, 'Carlo Phillip Anteja', '4988438843884305', '03/2030', '737', 100000);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `brand_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `item_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `brand_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `item_number`, `size`, `brand_name`, `price`, `image`) VALUES
(4, '00001', '9', 'Nike Air Force 1', 1999, 'image1.jpg'),
(5, '00002', '9.7', 'Nike Air Max 1', 2199, 'image2.jpg'),
(6, '00003', '10.6', 'Nike Air Jordan 1', 2699, 'image3.jpg'),
(8, '00004', '11', 'Nike Cortez', 2999, 'image4.jpg'),
(9, '00005', '9', 'Adidas Stan Smith', 2189, 'adidas1.jpg'),
(10, '00006', '9.6', 'Adidas Ultraboost', 2389, 'adidas2.jpg'),
(11, '00007', '10.7', 'Adidas Samba', 1699, 'adidas3.jpg'),
(12, '00008', '12', 'Adidas Yeezy', 3199, 'adidas4.jpg'),
(13, '00009', '9.2', 'Reebok Club D', 2499, 'reebok1.jpg'),
(14, '00010', '9.9', 'Reebok Club C', 3379, 'reebok2.jpg'),
(15, '0011', '10.1', 'Reebok Club B', 3399, 'reebok3.jpg'),
(16, '0012', '11.8', 'Reebok Club A', 3699, 'reebok4.jpg'),
(17, '0013', '9.9', 'Umbro Speciali Cup', 2759, 'umbro1.jpg'),
(18, '0014', '10.4', 'Umbro Run M LE', 3409, 'umbro2.jpg'),
(19, '0015', '11.7', 'Umbro Neptune 2.2', 4199, 'umbro3.jpg'),
(20, '0016', '12', 'Umbro Bumpy', 4329, 'umbro4.jpg'),
(21, '0017', '9.5', 'Kappa Salerno', 5039, 'kappa1.jpg'),
(22, '0018', '10.7', 'kappa Mide', 5249, 'kappa2.jpg'),
(23, '0019', '11', 'Kappa Mons', 5409, 'kappa3.jpg'),
(24, '0020', '12.7', 'Kappa Ostas', 5779, 'kappa4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `email`, `username`, `message`) VALUES
(11, '00anteja23@gmail.com', 'admin', 'shit face'),
(12, '00anteja23@gmail.com', 'admin', 'fuck yu!!'),
(13, 'carlophillipanteja19@gmail.com', 'carlo_pogi', 'hillo');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `items` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `fullname`, `email`, `address`, `city`, `province`, `items`, `total`) VALUES
(5, 'Bryan Aviso', 'aviso.bryan029@gmail.com', 'Blk 92 Lot 18 Southville 8B', 'Rodriguez', 'Rizal', ' Nike Air Max 1 | ', 2199),
(6, 'Carlo Anteja', 'carlophillipanteja19@gmail.com', 'safsafsa', 'safsaf', 'sfasaf', ' Nike Air Max 1 |  Nike Air Force 1 | ', 4198),
(7, 'Jdjdjd', '00anteja23@gmail.com', 'Dhdjjdd', 'Bzbzbz', 'Hjsjs', ' Nike Cortez | ', 2999),
(8, 'Robert Kean Anacion', 'evory.ivory.09@gmail.com', 'Blk 61 lot 48 phase 2a metro manila hills', 'Rodriguez', 'Rizal', ' Nike Cortez |  kappa Mide |  Adidas Yeezy |  Nike Air Force 1 | ', 13446),
(9, 'carlo phillip anteja ', 'carlophillipanteja19@gmail.com', 'blk yourself', 'Rodriquez', 'rizal', ' Nike Air Force 1 | ', 1999),
(10, 'carlo phillip anteja', 'carlophillipanteja19@gmail.com', 'blk yourself', 'Rodriquez', 'rizal', ' Nike Air Force 1 |  Nike Air Jordan 1 | ', 4698),
(11, 'dafasf', 'carlophillipanteja19@gmail.com', 'asfsaf', 'asfasf', 'fasfsaf', ' Nike Air Jordan 1 | ', 2699),
(12, 'Carlo Phillip Anteja', 'carlophillipanteja19@gmail.com', 'Kasiglahan Village', 'Montalban', 'Rizal', ' Nike Air Max 1 |  Nike Air Jordan 1 | ', 4898);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_activation_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `status`, `user_activation_code`) VALUES
(20, 'carlophillipanteja19@gmail.com', 'carlo_pogi', '12345', 'verified', '1be9bbb9e7a927393b60ecf09639676f'),
(32, '00python23@gmail.com', 'admin', 'admin123', 'verified', '63b3dadac237814e8789ba1a052df54d'),
(33, 'evory.ivory.09@gmail.com', 'Raizuki', '123456', 'verified', '44c17a47a12a01ea3603e2b42f10cd50'),
(34, '00anteja23@gmail.com', 'admin123', 'admin123', 'verified', '08053be8d1932947404fbddad7405c71'),
(35, 'urbangear2021@gmail.com', 'urbangear', '12345', 'verified', '8cbdb0cc52ef6e3bc2717ecb91434952'),
(36, 'alfonsoedgar026@gmail.com', 'fonsoy', '12345', 'verified', 'b882e50e44db38334eec18d0e55622a2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_number` (`item_number`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cards`
--
ALTER TABLE `cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
