<?php

    $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
    $isMob = is_numeric(strpos($ua, "mobile"));

    if ($isMob != 1)
    {
        header("location: index.php");
    }

?>

<!DOCTYPE html>

<html>

	<head>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Urban Gear</title>
		
        <link rel="icon" href="css/images/favicon.ico" type="image/gif" sizes="16x16">
	
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	</head>

	<body>

        <div class="container">

            <center>

                <h1 style="margin-top: 100px;">This site don't run on android browsers!</h1>

                <div style="margin-top: 100px;">

                    <p>Please check <strong>Enable Desktop Site</strong> on your browser to continue to the site. If the page does't automaticaly reload, please click <a href="index.php">this link</a>.</p>

                </div>

            </center>
    
        </div>

    </body>

</head>