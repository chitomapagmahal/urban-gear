<?php

    if (session_status() != PHP_SESSION_ACTIVE) 
    {
        session_start();
    }

    $CONNECT = new PDO('mysql:host=remotemysql.com;dbname=5HBFBiMCPb', '5HBFBiMCPb', 'WuN37JXSvD');

    $MESSAGE = '';

    if(isset($_GET['activation_code']))
    {
        $QUERY = " SELECT * FROM `users` WHERE user_activation_code = :user_activation_code ";
        $STATEMENT = $CONNECT->prepare($QUERY);
        $STATEMENT->execute( array(':user_activation_code'=>$_GET['activation_code']));
        $NO_OF_ROW = $STATEMENT->rowCount();
        
        if($NO_OF_ROW > 0)
        {
            $RESULT = $STATEMENT->fetchAll();
            
            foreach($RESULT as $ROW)
            {
                if($ROW['status'] == 'not verified')
                {
                    $UPDATE_QUERY = " UPDATE `users` SET `status` = 'verified' WHERE `id` = '".$ROW['id']."' ";
                    $STATEMENT = $CONNECT->prepare($UPDATE_QUERY);
                    $STATEMENT->execute();
                    $SUB_RESULT = $STATEMENT->fetchAll();

                    if(isset($SUB_RESULT))
                    {
                        $_SESSION['process-type'] = "login";
                        $_SESSION['alert-type'] = "success";
                        $_SESSION['message'] = "Account Verified! You can now login to your account.";

                        header("Location: login-register.php");
                    }
                }

                else
                {
                    $_SESSION['process-type'] = "login";
                    $_SESSION['alert-type'] = "warning";
                    $_SESSION['message'] = "This account is already verified! You can now login to your account.";

                    header("Location: login-register.php");
                }
            }
        }

        else
        {
            $_SESSION['process-type'] = "register";
            $_SESSION['alert-type'] = "error";
            $_SESSION['message'] = "This link is already invalid!";

            header("Location: login-register.php");
        }
    }
?>