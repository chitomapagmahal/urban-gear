<?php $TITLE = "Billing"; ?>

<?php include('header.php') ?>

<?php

    $SQL = "SELECT * FROM `users` WHERE `id`='". $_SESSION['login_id'] ."' ";
    $RESULT = mysqli_query($CONN, $SQL);

    $ROWS = mysqli_num_rows($RESULT);

	if ($ROWS > 0)
    {
        while ($USER_DETAILS = mysqli_fetch_array($RESULT))
        {
            $BILLING_ACCOUNT_EMAIL = $USER_DETAILS['email'];
        }
    }

?>

</div>
<!-- End Search, etc -->

<div id="content">

    <div id="container">

        <div id="tabbed">

            <div class="about_boxing-prop">

                <?php if (isset($_SESSION['alert-type'])): ?>

                <p class="<?php echo $ALERT_TYPE ?>"><?php echo $_SESSION['message'] ?></p>

                <?php unset($_SESSION['alert-type']); ?>

                <?php endif; ?>

                <div class="about_about-section">
                    
                    <h1>Billing</h1>
                    
                </div>

                <br>

                <hr class="update_hr">

                <br>

                <div class="billing_row">
  
                    <div class="billing_col-75">
    
                        <div class="billing_container">
      
                            <form action="" method="POST">
        
                                <div class="billing_row">
          
                                    <div class="billing_col-50">

                                        <?php

                                            $ITEM_SQL = "SELECT * FROM `cart` WHERE `user_id`='". $_SESSION['login_id'] ."' ";
                                            $ITEM_RESULT = mysqli_query($CONN, $ITEM_SQL);

                                            $ITEM_ROWS = mysqli_num_rows($ITEM_RESULT);

                                        ?>

                                        <br>

                                        <label class="billing_label"><i class="fa fa-user"></i> Full Name</label>
                                        <input class="billing_inputs" type="text" name="fullname" placeholder="Enter Fullname" required <?php if ($ITEM_ROWS == 0) {echo "disabled";} ?>>
                                        
                                        <label class="billing_label"><i class="fa fa-envelope"></i> Email</label>
                                        <input class="billing_inputs" type="text" name="email" value="<?php echo $BILLING_ACCOUNT_EMAIL; ?>" readonly <?php if ($ITEM_ROWS == 0) {echo "disabled";} ?>>
                                        
                                        <label class="billing_label"><i class="fa fa-address-card-o"></i> Address</label>
                                        <input class="billing_inputs" type="text" name="address" placeholder="Street Name, House No, Block No, Lot No, Phase No, Village Name, Barangay Name" required <?php if ($ITEM_ROWS == 0) {echo "disabled";} ?>>
                                        
                                        <label class="billing_label"><i class="fa fa-institution"></i> City</label>
                                        <input class="billing_inputs" type="text" name="city" placeholder="Enter City" required <?php if ($ITEM_ROWS == 0) {echo "disabled";} ?>>
                                        
                                        <label class="billing_label"><i class="fa fa-home"></i> Province</label>
                                        <input class="billing_inputs" type="text" name="province" placeholder="Enter Province" required <?php if ($ITEM_ROWS == 0) {echo "disabled";} ?>>
                                        
                                    </div>
          
                                </div>
         
                                <input type="submit" value="Continue to Checkout" class="billing_btn" name="store_data_for_checkout" <?php if ($ITEM_ROWS == 0) {echo "disabled";} ?>>
      
                            </form>
    
                        </div>
  
                    </div>
  
                    <div class="billing_col-25">
    
                        <div class="billing_container">

                                <?php

                                    $SQL = "SELECT * FROM `cart` WHERE `user_id`='". $_SESSION['login_id'] ."' ";
                                    $RESULT = mysqli_query($CONN, $SQL);

                                    $ROWS = mysqli_num_rows($RESULT);

                                    $TOTAL = 0;
                                    $ITEMS = "";

                                ?>

                                <?php if ($ROWS > 0): ?>

                                    <h4>Cart <span class="billing_price" style="color:black"><i class="fa fa-shopping-cart"></i> <b><?php echo $ROWS; ?></b></span></h4>

                                    <br>
											
                                    <?php while ($USER_DETAILS = mysqli_fetch_array($RESULT)): ?> 
                                        
                                        <form action="" method="POST">

                                            <p>
                                                <input type="text" name="remove_item" value="<?php echo $USER_DETAILS['id']; ?>" style="width: 0; height: 0; opacity: 0;" readonly>

                                                <input type="submit" value="x" class="billing_remove" name="remove">
                                                
                                                <span>
                                                    
                                                    <?php echo $USER_DETAILS['brand_name']; ?>
                                                
                                                </span>
                                                
                                                <span class="billing_price">
                                                    
                                                    ₱<?php echo $USER_DETAILS['price']; ?>.00
                                                
                                                </span>
                                            
                                            </p>

                                        </form>

                                        <?php $TOTAL = $TOTAL + $USER_DETAILS['price']; ?>
                                        <?php $ITEMS = $ITEMS . $USER_DETAILS['brand_name']." | "; ?>

                                    <?php endwhile; ?>
                                    
                                    <?php $_SESSION['total'] = $TOTAL ?>
                                    <?php $_SESSION['items'] = $ITEMS ?> 

                                    <br>

                                    <hr>

                                    <p>Total <span class="billing_price" style="color:black"><b>₱<?php echo $TOTAL ?>.00</b></span></p>

                                <?php else: ?>

                                    <h4>Cart <span class="billing_price" style="color:black"><i class="fa fa-shopping-cart"></i> <b><?php echo $ROWS; ?></b></span></h4>

                                    <br>

                                    <p>There is no item in your cart.</p>

                                <?php endif; ?>

                        </div>
  
                    </div>

                </div>

<?php include('footer.php'); ?>