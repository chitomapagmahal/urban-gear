<?php

	include('server.php');
	
	if (isset($_SESSION['current_user']))
    {
        $CURRENT_USER = $_SESSION['current_user'];

        $SQL = "SELECT * FROM `users` WHERE `username`='". $CURRENT_USER . "' LIMIT 1";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) <= 0)
        {
            header('Location: login-register.php');
        }
    }

    else
    {
        header('Location: login-register.php');
    }

	if (isset($_SESSION['alert-type']))
	{
		if ($_SESSION['alert-type'] == "success")
		{
			$ALERT_TYPE = "success-text";
		}

		if ($_SESSION['alert-type'] == "warning")
		{
			$ALERT_TYPE = "warning-text";
		}

		if ($_SESSION['alert-type'] == "error")
		{
			$ALERT_TYPE = "error-text";
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Payment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" type="text/css" href="payment-assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="payment-assets/font-awesome/css/font-awesome.min.css" />

    <link rel="icon" href="css/images/favicon.ico" type="image/gif" sizes="16x16">

    <script type="text/javascript" src="payment-assets/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="payment-assets/bootstrap/js/bootstrap.min.js"></script>

    <style>

        .error-text
        {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
            width: 100%;
            text-align: center;
            padding-top: 5px;
            padding-bottom: 5px;
            position: relative;
            margin-bottom: 2rem;
            border: 1px solid transparent;
            border-radius: .25rem;
        }

        .success-text
        {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
            width: 100%;
            text-align: center;
            padding-top: 5px;
            padding-bottom: 5px;
            position: relative;
            margin-bottom: 2rem;
            border: 1px solid transparent;
            border-radius: .25rem;
        }

        .warning-text
        {
            color: #856404;
            background-color: #fff3cd;
            border-color: #ffeeba;
            border-color: #c3e6cb;
            width: 100%;
            text-align: center;
            padding-top: 5px;
            padding-bottom: 5px;
            position: relative;
            margin-bottom: 2rem;
            border: 1px solid transparent;
            border-radius: .25rem;
        }

    </style>

</head>
<body style="background-image: url('payment-assets/bg.png');">

<div class="container">

<div class="page-header" style="color: white;">

    <center><h1>Total Price:<strong> ₱<?php if(isset($_SESSION['total'])){echo $_SESSION['total'];} else { echo "0";} ?>.00</strong> </h1></center>

</div>

<!-- Credit Card Payment Form - START -->

<div class="container">

    <div class="row">
        <div class="col-xs-12 col-md-4 col-md-offset-4">
            <div class="panel panel-default">
                <div class="panel-heading">

                    <?php if (isset($_SESSION['alert-type'])): ?>

                    <p class="<?php echo $ALERT_TYPE ?>"><?php echo $_SESSION['message'] ?></p>

                    <?php unset($_SESSION['alert-type']); ?>

                    <?php endif; ?>

                    <div class="row">
                        <h3 class="text-center">Payment Details</h3>
                        <img class="img-responsive cc-img" src="payment-assets/creditcardicons.png">
                    </div>
                </div>
                <div class="panel-body">
                    <form role="form" action="" method="POST">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label>CARD NUMBER</label>
                                    <div class="input-group">
                                        <input type="tel" class="form-control" placeholder="Valid Card Number" name="card_number" />
                                        <span class="input-group-addon"><span class="fa fa-credit-card"></span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-7 col-md-7">
                                <div class="form-group">
                                    <label><span class="hidden-xs">EXPIRATION</span><span class="visible-xs-inline">EXP</span> DATE</label>
                                    <input type="tel" class="form-control" placeholder="MM / YY" name="expiration_date"/>
                                </div>
                            </div>
                            <div class="col-xs-5 col-md-5 pull-right">
                                <div class="form-group">
                                    <label>CV CODE</label>
                                    <input type="tel" class="form-control" placeholder="CVC" name="cvc" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label>CARD OWNER</label>
                                    <input type="text" class="form-control" placeholder="Card Owner Names" name="card_owner" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <div class="row">
                            <div class="col-md-12" style="margin-bottom: 10px;">
                                <button class="btn btn-success btn-lg btn-block" type="submit" name="checkout">Process Payment</button>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <a href="billing.php" class="btn btn-danger btn-lg btn-block">Back</a>
                            </div>
                        </div>
                    </div>

                </form>
            
            </div>
        </div>
    </div>
</div>

<style>
    .cc-img {
        margin: 0 auto;
    }
</style>
<!-- Credit Card Payment Form - END -->

</div>

</body>
</html>