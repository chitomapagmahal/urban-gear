<?php $TITLE = "Update Account"; ?>

<?php include('header.php'); ?>

<?php

    $SQL = "SELECT * FROM `users` WHERE `id`='". $_SESSION['login_id'] ."' ";
    $RESULT = mysqli_query($CONN, $SQL);

    while ($USER_DETAILS = mysqli_fetch_array($RESULT))
    {
        $MY_ACCOUNT_EMAIL = $USER_DETAILS['email'];
        $MY_ACCOUNT_USERNAME = $USER_DETAILS['username'];
        $MY_ACCOUNT_PASSWORD = $USER_DETAILS['password'];
    }

?>

</div>
<!-- End Search, etc -->

<div id="content">

    <div id="container">

        <div id="tabbed">

            <div class="about_boxing-prop">

                <?php if (isset($_SESSION['alert-type'])): ?>

                <p class="<?php echo $ALERT_TYPE ?>"><?php echo $_SESSION['message'] ?></p>

                <?php unset($_SESSION['alert-type']); ?>

                <?php endif; ?>

                <div class="about_about-section">
                    
                    <h1>Update Account</h1>
                    
                </div>

                <br>

                <hr class="update_hr">

                <br>

                <div class="contact_container">
                    
                    <form action="" method="POST">
    
                        <label>Email</label>
                        <input class="contact_input" type="text" placeholder="Enter Email" name="update_email" value="<?php echo $MY_ACCOUNT_EMAIL ?>" required>

                        <label for="username">Username</label>
                        <input class="contact_input" type="text" placeholder="Enter Username" name="update_username" value="<?php echo $MY_ACCOUNT_USERNAME ?>" required>

                        <label>Enter Password</label>
                        <input class="contact_input" type="password" placeholder="Enter Password" name="update_password" value="<?php echo $MY_ACCOUNT_PASSWORD ?>" required>

                        <input class="contact_submit_btn" type="submit" value="Update" name="update">
  
                    </form>

                </div>

<?php include('footer.php'); ?>