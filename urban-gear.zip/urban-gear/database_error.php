<?php

header('HTTP/1.1 503 Service Temporarily Unavailable');
header('Status: 503 Service Temporarily Unavailable');
header('Retry-After: 600'); // 1 hour = 3600 seconds

?>

<!DOCTYPE HTML>
<html>

<head>
    <title>Database Error</title>
    <link rel="icon" href="css/images/favicon.ico" type="image/gif" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            padding: 20px;
            color: red;
            font-size: 60px;
        }
    </style>
</head>

<body>
    <div class="container">
        <p style="text-align: justify;">There is an error in connecting to the Database. If this happens during checking, please use the <a href='https://github.com/chitomapagmahal/urban-gear.git'>Offline Version</a> of the website. Please import this <a href="urban_gear.sql">SQL File</a> to a database named "urban_gear". Check "server.php" to change parameters of the database connection.</p>
        
        <button class="btn btn-success" style="width: 100%;" type="button" onclick="reload_homepage()">Reload Homepage</button>
    </div>

    <script>
        function reload_homepage() {
            window.location.href = "index.php";
        }
    </script>

</body>

</html>