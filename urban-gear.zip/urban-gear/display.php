<?php

    /* Display */

    if (isset($_POST['search']))
    {
		$SEARCH_ITEM_NAME = $_POST['search_item_name'];

		if ($SEARCH_ITEM_NAME == "" or $SEARCH_ITEM_NAME == "Search Brand Name")
		{
			$SQL = "SELECT * FROM `items`";
	    	$RESULT = mysqli_query($CONN, $SQL);

	    	$ROWS = mysqli_num_rows($RESULT);
		}

		else
		{
			$SQL = "SELECT * FROM `items` WHERE `brand_name` LIKE '". $SEARCH_ITEM_NAME ."%' ";
			$RESULT = mysqli_query($CONN, $SQL);

			$ROWS = mysqli_num_rows($RESULT);

			if ($ROWS <= 0)
			{
				$_SESSION['alert-type'] = "error";
                $_SESSION['message'] = "There are no results in your search query.";
			}
		}
    }

    else
    {
        $SQL = "SELECT * FROM `items`";
	    $RESULT = mysqli_query($CONN, $SQL);

	    $ROWS = mysqli_num_rows($RESULT);
    }

?>