<?php

	include('server.php');
	
	if (isset($_SESSION['current_user']))
    {
        $CURRENT_USER = $_SESSION['current_user'];

        $SQL = "SELECT * FROM `users` WHERE `username`='". $CURRENT_USER . "' LIMIT 1";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) <= 0)
        {
            header('Location: login-register.php');
        }
    }

    else
    {
        header('Location: login-register.php');
    }

	if (isset($_SESSION['alert-type']))
	{
		if ($_SESSION['alert-type'] == "success")
		{
			$ALERT_TYPE = "success-text";
		}

		if ($_SESSION['alert-type'] == "warning")
		{
			$ALERT_TYPE = "warning-text";
		}

		if ($_SESSION['alert-type'] == "error")
		{
			$ALERT_TYPE = "error-text";
		}
	}

?>

<!DOCTYPE html>

<html>

	<head>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Urban Gear<?php if ($TITLE != ""){echo " - ".$TITLE;} ?></title>
		
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css" type="text/css"/>
		<link rel="icon" href="css/images/favicon.ico" type="image/gif" sizes="16x16">
	
		<script src="js/jquery-1.4.1.min.js" type="text/javascript"></script>
		<script src="js/jquery.jcarousel.pack.js" type="text/javascript"></script>
		<script src="js/jquery.slide.js" type="text/javascript"></script>
		<script src="js/jquery-func.js" type="text/javascript"></script>
		
	</head>

	<body>
	
		<!-- Top -->
		<div id="top">
			
			<div class="shell">
				
				<!-- Header -->
				<div id="header">
					
					<h1 id="logo" style="color: white;"><a href="index.php">Urban Gear</a></h1>
					
					<div id="navigation">
						
						<ul>
							
							<li><a href="index.php"><span class="fa fa-home"></span> Home</a></li>
							<li><a href="about.php"><span class="fa fa-info-circle"></span> About</a></li>
							<li><a href="contact.php"><span class="fa fa-address-book"></span> Contact</a></li>
							<li><a href="update_account.php"><span class="fa fa-user"></span> My Account</a></li>
							<li><a href="balance_checker.php"><span class="fa fa-credit-card"></span> Card Balance Checker</a></li>
							<li class="last"><a href="logout.php" style="color: red;"><span class="fa fa-sign-out"></span> Logout</a></li>
						
						</ul>
					
					</div>
				
				</div>
				<!-- End Header -->
				
				<!-- Slider -->
				<div class="slideshow-container">

					<div class="mySlides fade">
					
						<img class="slide_img" src="css/images/bg.jpg" style="width:100%">
					
					</div>

					<div class="mySlides fade">
					
						<img class="slide_img" src="css/images/slide1.jpg" style="width:100%">
					
					</div>

					<div class="mySlides fade">
					
						<img class="slide_img" src="css/images/slide2.jpg" style="width:100%">
					
					</div>

					</div>
					
					<div style="text-align:center">
						<span class="dot"></span> 
						<span class="dot"></span> 
						<span class="dot"></span>

					</div>

				</div>
				<!-- End Slider -->
				
			</div>
		
		</div>
		<!-- End Top -->

		<div id="main">

            <div class="shell">

                <!-- Search, etc -->
				<div class="options">

					<div class="right">
						
						<span class="cart">
							
							<a href="billing.php" class="cart-ico">&nbsp;</a>

							<?php 
							
								$SQL = "SELECT * FROM `cart` WHERE `user_id` = '". $_SESSION['login_id'] ."'";
								$RESULT = mysqli_query($CONN, $SQL);

								if (mysqli_num_rows($RESULT) > 0)
        						{
									$TOTAL_CART_PRICE = 0;

									while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            						{
										$TOTAL_CART_PRICE = $TOTAL_CART_PRICE + $USER_DETAILS['price'];
									}
								}

								else
								{
									$TOTAL_CART_PRICE = "0";
								}
							
							?>

							<strong>₱<?php echo $TOTAL_CART_PRICE ?>.00</strong>
						
						</span>
						
					</div>