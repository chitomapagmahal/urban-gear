<?php 

	include('server.php'); 
	
	if (isset($_SESSION['alert-type']))
	{
		if ($_SESSION['alert-type'] == "success")
		{
			$ALERT_TYPE = "success-text";
		}

		if ($_SESSION['alert-type'] == "warning")
		{
			$ALERT_TYPE = "warning-text";
		}

		if ($_SESSION['alert-type'] == "error")
		{
			$ALERT_TYPE = "error-text";
		}
	}
?>

<!DOCTYPE HTML>

<html>

	<head>
		
		<title>Urban Gear - Log In or Sign Up</title>
		
		<meta name="viewport" content="width=device-width, initial-scale=1" charset="UTF-8">
		
		<link rel="stylesheet" href="login-assets/css/style.css" type="text/css" media="all" />
		<link href="login-assets/css/font-awesome.min.css" rel="stylesheet">
        <link rel="icon" href="css/images/favicon.ico" type="image/gif" sizes="16x16">
		
	</head>

	<body>
		
		<div class="main-bg">
			
			<h1>Urban Gear</h1>
			
			<div class="sub-main-w3">

				<?php if (isset($_SESSION['alert-type'])): ?>

				<p class="<?php echo $ALERT_TYPE ?>"><?php echo $_SESSION['message'] ?></p>

				<?php unset($_SESSION['alert-type']); ?>
				
				<?php endif; ?>

				<div class="image-style"></div>
				
				<!-- vertical tabs -->
				<div class="vertical-tab">
					
					<div id="section1" class="section-w3ls">
						
						<?php if (isset($_SESSION['process-type'])): ?>
						
							<?php if ($_SESSION['process-type'] == "login"): ?>
					
								<input type="radio" name="sections" id="option1" checked>

							<?php else: ?>

								<input type="radio" name="sections" id="option1">

							<?php endif; ?>

						<?php else: ?>

							<input type="radio" name="sections" id="option1" checked>

						<?php endif; ?>
						
						<label for="option1" class="icon-left-w3pvt"><span class="fa fa-user-circle" aria-hidden="true"></span>Login</label>
						
						<article>
							
							<form action="login-register.php" method="POST">
								
								<h3 class="legend">Login Here</h3>
								
								<div class="input">
						
									<span class="fa fa-user-o" aria-hidden="true"></span>
									<input type="text" placeholder="Username" name="login_username" required/>
						
								</div>
								
								<div class="input">
									
									<span class="fa fa-key" aria-hidden="true"></span>
									<input type="password" placeholder="Password" name="login_password" required/>
								
								</div>
								
								<button type="submit" class="btn submit" name="login">Login</button>
								
								<a href="#" class="bottom-text-w3ls">You agreed to our privacy policy.</a>

							</form>

						</article>

					</div>

					<div id="section2" class="section-w3ls">
						
						<?php if (isset($_SESSION['process-type'])): ?>
						
							<?php if ($_SESSION['process-type'] == "register"): ?>
						
								<input type="radio" name="sections" id="option2" checked>

							<?php else: ?>

								<input type="radio" name="sections" id="option2">

							<?php endif; ?>

						<?php else: ?>

							<input type="radio" name="sections" id="option2">

						<?php endif; ?>
	
						<label for="option2" class="icon-left-w3pvt"><span class="fa fa-pencil-square" aria-hidden="true"></span>Register</label>
						
						<article>
						
							<form action="login-register.php" method="POST">
						
								<h3 class="legend">Register Here</h3>
								
								<div class="input">
									
									<span class="fa fa-envelope-o" aria-hidden="true"></span>
									<input type="email" placeholder="Email" name="register_email" required/>
								
								</div>

								<div class="input">
						
									<span class="fa fa-user-o" aria-hidden="true"></span>
									<input type="text" placeholder="Username" name="register_username" required/>
						
								</div>
						
								<div class="input">
						
									<span class="fa fa-key" aria-hidden="true"></span>
									<input type="password" placeholder="Password" name="register_password" required/>
						
								</div>
						
								<button type="submit" class="btn submit" name="register">Register</button>
						
							</form>
						
						</article>
					
					</div>
					
					<div id="section3" class="section-w3ls">
					
						<?php if (isset($_SESSION['process-type'])): ?>
							
							<?php if ($_SESSION['process-type'] == "forgot"): ?>
						
								<input type="radio" name="sections" id="option3" checked>

							<?php else: ?>

								<input type="radio" name="sections" id="option3">

							<?php endif; ?>

						<?php else: ?>

							<input type="radio" name="sections" id="option3">

						<?php endif; ?>

						<label for="option3" class="icon-left-w3pvt"><span class="fa fa-lock" aria-hidden="true"></span>Forgot Account?</label>
					
						<article>
						
							<form action="login-register.php" method="POST">
						
								<h3 class="legend last">Retrieve Account</h3>
						
								<p class="para-style">Enter your email address below and we'll send you an email with instructions.</p>
								<p class="para-style-2"><strong>Need Help?</strong> Please contact our <a href="#">Techinical Support Team.</a></p>
								
								<div class="input">
								
									<span class="fa fa-envelope-o" aria-hidden="true"></span>
									<input type="email" placeholder="Email" name="forgot_email" required />
								
								</div>
								
								<button type="submit" class="btn submit last-btn" name="forgot_password">Send</button>
							
							</form>
						
						</article>
				
					</div>
				
				</div>
				
				<div class="clear"></div>
			</div>
			
			<div class="copyright">

				<h2>&copy; 2021 Urban Gear. All rights reserved</h2>
			
			</div>
			
		</div>

	</body>

</html>