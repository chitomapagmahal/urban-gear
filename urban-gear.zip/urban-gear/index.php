<?php $TITLE = ""; ?>

<?php include('header.php'); ?>

<?php

	/* Display */

    if (isset($_POST['search']))
    {
		$SEARCH_ITEM_NAME = $_POST['search_item_name'];

		if ($SEARCH_ITEM_NAME == "" or $SEARCH_ITEM_NAME == "Search Brand Name")
		{
			$SQL = "SELECT * FROM `items`";
	    	$RESULT = mysqli_query($CONN, $SQL);

	    	$ROWS = mysqli_num_rows($RESULT);
		}

		else
		{
			$SQL = "SELECT * FROM `items` WHERE `brand_name` LIKE '". $SEARCH_ITEM_NAME ."%' ";
			$RESULT = mysqli_query($CONN, $SQL);

			$ROWS = mysqli_num_rows($RESULT);

			if ($ROWS <= 0)
			{
				$_SESSION['alert-type'] = "error";
                $_SESSION['message'] = "<center class='warning-text';>There are no results in your search query.</center>";
			}
		}
    }

    else
    {
        $SQL = "SELECT * FROM `items`";
	    $RESULT = mysqli_query($CONN, $SQL);

	    $ROWS = mysqli_num_rows($RESULT);
    }
?>

					<div class="search">
							
						<form action="" method="POST">
								
							<span class="field"><input name="search_item_name" type="text" class="blink" value="Search Brand Name" title="Search Brand Name"/></span>
								
							<input name="search" type="submit" class="search-submit" value="GO" />
							
						</form>
						
					</div>

				</div>
				<!-- End Search, etc -->

				<div id="content">

					<div id="container">

						<div id="tabbed">

							<?php if (isset($_SESSION['alert-type'])): ?>

							<p class="<?php echo $ALERT_TYPE ?>"><?php echo $_SESSION['message'] ?></p>

							<?php unset($_SESSION['alert-type']); ?>

							<?php endif; ?>
					
							<!-- First Tab Content -->
							<div class="tab-content" style="display:block;">
								
								<div class="items">
									
									<div class="cl">&nbsp;</div>
									
									<ul>

										<?php if ($ROWS > 0): ?>
											
											<?php while ($USER_DETAILS = mysqli_fetch_array($RESULT)): ?>

												<li>

													<form action="" method="POST">
													
														<div class="image">
														
															<img src="css/images/<?php echo $USER_DETAILS['image']; ?>" alt=""/>
													
														</div>
													
														<p>
															Item Number: <input class="item_data" type="text" name="add_item_number" value=" <?php echo $USER_DETAILS['item_number']; ?>" readonly></input><br/>
															Size: <input class="item_data" type="text" name="add_item_size" value=" <?php echo $USER_DETAILS['size']; ?>" readonly></input><br/>
															Brand Name: <input class="item_data" type="text" name="add_item_name" value=" <?php echo $USER_DETAILS['brand_name']; ?>" readonly></input>
														</p>
													
														<p class="price">Price: <span class="item_data item_data_strong">₱</span><input class="item_data item_data_strong" type="text" name="add_item_price" value=" <?php echo $USER_DETAILS['price']; ?>.00" readonly></input></p>

														<button type="submit" name="add_to_cart" class="button button2"><span class="fa fa-shopping-cart"></span> Add to Cart</button>
														
													</form>

												</li>

											<?php endwhile; ?>

										<?php endif; ?>

									</ul>

									<div class="cl">&nbsp;</div>
								
								</div>
							
							</div>
							<!-- End First Tab Content -->
						
<?php include('footer.php') ?>				