						</div>

						<!-- Brands -->
				        <div class="brands">
                        
                            <h3>Brands</h3>
                            
                            <div class="logos">
                                
                                <a style="cursor: default;" onclick="my_autoscroll()"><img src="css/images/logo1.gif" alt="" /></a>
                                <a style="cursor: default;" onclick="my_autoscroll1()"><img src="css/images/logo2.gif" alt="" /></a>
                                <a style="cursor: default;" onclick="my_autoscroll2()"><img src="css/images/logo3.gif" alt="" /></a>
                                <a style="cursor: default;" onclick="my_autoscroll3()"><img src="css/images/logo4.gif" alt="" /></a>
                                <a style="cursor: default;" onclick="my_autoscroll4()"><img src="css/images/logo5.gif" alt="" /></a>
                            
                            </div>
                    
                        </div>
                        <!-- End Brands -->

						<!-- Footer -->
						<div id="footer">
							
							<div class="left">
								
								<a href="index.php">Home</a>
								
								<span>|</span>
								
								<a href="about.php">About</a>
								
								<span>|</span>
								
								<a href="contact.php">Contact</a>
								
								<span>|</span>
								
								<a href="update_account.php">My Account</a>
								
								<span>|</span>
								
								<a href="update_account.php">Card Balance Checker</a>

							</div>
							
							<div class="right">
								
								&copy; 2021 Urban Gear. All rights reserved
							
							</div>

						</div>

						<!-- End Footer -->
						
					</div>
					<!-- End Container -->
					
				</div>
				<!-- End Content -->
				
			</div>
			
		</div>
		<!-- End Main -->
		
		<!-- auto scroll script -->
		<script>
		
			var slideIndex = 0;
			showSlides();

			function showSlides() 
			{
				var i;
				var slides = document.getElementsByClassName("mySlides");
				var dots = document.getElementsByClassName("dot");
				
				for (i = 0; i < slides.length; i++) 
				{
					slides[i].style.display = "none";  
				}
				
				slideIndex++;
				
				if (slideIndex > slides.length) 
				{
					slideIndex = 1
				}    
				
				for (i = 0; i < dots.length; i++) 
				{
					dots[i].className = dots[i].className.replace(" active", "");
				}
				
				slides[slideIndex-1].style.display = "block";  
				dots[slideIndex-1].className += " active";
				
				setTimeout(showSlides, 2000);
			}

		</script>
		<!-- end script -->	
	</body>

</html>