<?php $TITLE = "About Us"; ?>

<?php include('header.php'); ?>

</div>
<!-- End Search, etc -->

<div id="content">

    <div id="container">

        <div id="tabbed">

            <div class="about_boxing-prop">

                <div class="about_about-section">
                    
                    <h1>About Us</h1>
                    
                </div>

                <br>

                <hr class="update_hr">

                <h2 style="text-align:center; color: black;">Our Team</h2>
                
                <br>

                <div class="about_row">
                    
                    <div class="about_column">
                        
                        <div class="about_card">
                        
                            <img src="css\images\carlo_pic.jpg" alt="Jane" style="width:100%">
                    
                            <div class="about_container">
                            
                                <br>
                            
                                <h2 style="text-align:center; color: black;">Carlo Phillip Anteja</h2>
                                <p style="text-align:center; color: gray;">Member</p>
                            
                                <br>

                                <hr class="update_hr">
                            
                                <p style="color: black;">" Although education is the most valuable asset we can own, that is why it's important to study diligently but remember, don't forget to drink alcohol! "</p>
                            
                                <br>
                    
                            </div>
                    
                        </div>
                
                    </div>

                    <div class="about_column">
                        
                        <div class="about_card">
                        
                            <img src="css\images\bry_pic.jpg" alt="Jane" style="width:100%">
                    
                            <div class="about_container">
                            
                                <br>
                            
                                <h2 style="text-align:center; color: black;">Bryan Aviso</h2>
                                <p style="text-align:center; color: gray;">Member</p>
                            
                                <br>

                                <hr class="update_hr">
                            
                                <p style="color: black;">" You need to accept the fact that you’re not the best and have all the will to strive to be better than anyone you face. "</p>
                            
                                <br>
                    
                            </div>
                    
                        </div>
                
                    </div>

                </div>

                <div class="about_row">
                    
                    <div class="about_column">
                        
                        <div class="about_card">
                        
                            <img src="css\images\varao_pic.jpg" alt="Jane" style="width:100%">
                    
                            <div class="about_container">
                            
                                <br>
                            
                                <h2 style="text-align:center; color: black;">Willy Mark Vinarao</h2>
                                <p style="text-align:center; color: gray;">Member</p>
                            
                                <br>

                                <hr class="update_hr">
                            
                                <p style="color: black;">" Respect your parents. They passed school without Google. "</p>
                            
                                <br>
                    
                            </div>
                    
                        </div>
                
                    </div>

                    <div class="about_column">
                        
                        <div class="about_card">
                        
                            <img src="css\images\kean_pic.jpg" alt="Jane" style="width:100%">
                    
                            <div class="about_container">
                            
                                <br>
                            
                                <h2 style="text-align:center; color: black;">Robert Kean Anacion</h2>
                                <p style="text-align:center; color: gray;">Member</p>
                            
                                <br>

                                <hr class="update_hr">
                            
                                <p style="color: black;">" Your past will never experience your future. So keep moving forward. "</p>
                            
                                <br>
                    
                            </div>
                    
                        </div>
                
                    </div>

                </div>
                
                <div class="about_row">
                    
                    <div class="about_column">
                        
                        <div class="about_card">
                        
                            <img src="css\images\jin_pic.jpg" alt="Jane" style="width:100%">
                    
                            <div class="about_container">
                            
                                <br>
                            
                                <h2 style="text-align:center; color: black;">Jin Vincent Mabilog</h2>
                                <p style="text-align:center; color: gray;">Member</p>
                            
                                <br>

                                <hr class="update_hr">
                            
                                <p style="color: black;">" Rules are meant to be broken. "</p>
                            
                                <br>
                    
                            </div>
                    
                        </div>
                
                    </div>

                </div>

            </div>

<?php include('footer.php'); ?>