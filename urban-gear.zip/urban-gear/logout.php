<?php
    
    if (session_status() != PHP_SESSION_ACTIVE)
    {
        session_start();
    }
    
    unset($_SESSION["current_user"]);
    unset($_SESSION["login_id"]);

    $_SESSION['process-type'] = "login";
    $_SESSION['alert-type'] = "error";
    $_SESSION['message'] = "You had been logged out.";

    header("Location: index.php");
?>