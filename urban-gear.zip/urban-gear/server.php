<?php

    $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
    $isMob = is_numeric(strpos($ua, "mobile"));

    if ($isMob == 1)
    {
        header("location: enable_desktop_site.php");
    }

    date_default_timezone_set("Asia/Manila");
    
    $date = date_create(date("Y-m-d"));

    if (session_status() != PHP_SESSION_ACTIVE) 
    {
        session_start();
    }

    function url()
    {
        return sprintf("%s://%s/", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['SERVER_NAME'],);
    }

    $SERVER = 'remotemysql.com';
    $USER = '5HBFBiMCPb';
    $PASSWORD = 'WuN37JXSvD';
    $DATABASE = '5HBFBiMCPb';

    /* Use this parameters in case of database error */
    // $SERVER = 'localhost';
    // $USER = 'root';
    // $PASSWORD = '';
    // $DATABASE = 'urban_gear';

    $CONN = mysqli_connect($SERVER, $USER, $PASSWORD, $DATABASE) or header("location: database_error.php");

    /* SMTP */

    require 'smtp/PHPMailer.php';
	require 'smtp/SMTP.php';
	require 'smtp/Exception.php';
	
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;

    //$BASE_URL = "http://localhost/urban-gear/";
	$BASE_URL = url();

	$MAIL = new PHPMailer();

	$MAIL->isSMTP();
	$MAIL->SMTPAuth = true;
	$MAIL->SMTPSecure = 'tls';
	$MAIL->Host = 'smtp.gmail.com';
	$MAIL->Port = '587';
	$MAIL->Username = 'urbangear2021@gmail.com';
	$MAIL->Password = '09465287111';
	$MAIL->SetFrom('urbangear2021@gmail.com');
    $MAIL->isHTML();
    $MAIL->FromName = 'Urban Gear';

    /* Login */

    if (isset($_POST['login']))
    {
        $LOGIN_USERNAME = $_POST['login_username'];
        $LOGIN_PASSWORD = $_POST['login_password'];

        $SQL = "SELECT * FROM `users` WHERE `username`='". $LOGIN_USERNAME ."' AND `password`='". $LOGIN_PASSWORD ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
            while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            {
                $_SESSION['login_id'] = $USER_DETAILS['id'];
                
                $DATA_USERNAME =  $USER_DETAILS['username'];
                $DATA_PASSWORD =  $USER_DETAILS['password'];
                $DATA_STATUS =  $USER_DETAILS['status'];

                if (($LOGIN_USERNAME == $DATA_USERNAME) and ($LOGIN_PASSWORD == $DATA_PASSWORD))
                {
                    if ($DATA_STATUS == 'verified')
                    {
                        $_SESSION["current_user"] = $DATA_USERNAME;

                        header("Location: index.php");
                    }

                    else
                    {
                        $_SESSION['process-type'] = "login";
                        $_SESSION['alert-type'] = "error";
                        $_SESSION['message'] = "This account is not yet verified. Please check your email to verify your account.";
                    }
                }

                else
                {
                    $_SESSION['process-type'] = "login";
                    $_SESSION['alert-type'] = "error";
                    $_SESSION['message'] = "Invalid username or password.";
                }
            }
        }

        else
        {
            $_SESSION['process-type'] = "login";
            $_SESSION['alert-type'] = "error";
            $_SESSION['message'] = "Invalid username or password.";
        }

    }

    /* Register */

    if (isset($_POST['register']))
    {
        $REGISTER_EMAIL = $_POST['register_email'];
        $REGISTER_USERNAME = $_POST['register_username'];
        $REGISTER_PASSWORD = $_POST['register_password'];
        
        $IS_USERNAME_VALID = TRUE;
        $IS_EMAIL_VALID = TRUE;

        $SQL = "SELECT * FROM `users` WHERE `username`='". $REGISTER_USERNAME ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
            $_SESSION['process-type'] = "register";  
            $_SESSION['alert-type'] = "error";
            $_SESSION['message'] = "Username already exists!";

            $IS_USERNAME_VALID = FALSE;
        }

        $SQL = "SELECT * FROM `users` WHERE `email`='". $REGISTER_EMAIL ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {   
            $_SESSION['process-type'] = "register";
            $_SESSION['alert-type'] = "error";
            $_SESSION['message'] = "Email already exists!";

            $IS_EMAIL_VALID = FALSE;
        }

        if ($IS_EMAIL_VALID == TRUE and $IS_USERNAME_VALID == TRUE)
        {
            $ACTIVATION_CODE = md5(rand());
            $MAIL_BODY = "
    
                <p>Hi ".$REGISTER_USERNAME.",</p>
		        <p>Please Open this link to verify your email address - ".$BASE_URL."account_verification.php?activation_code=".$ACTIVATION_CODE."
		        <p>Best Regards,<br>Urban Gear</p>";

            $MAIL->Subject = 'Activate Account';
            $MAIL->Body = $MAIL_BODY;
            $MAIL->AddAddress($REGISTER_EMAIL);
            
            if ($MAIL->Send())
            {
                $SQL = "INSERT INTO `users` (`email`, `username`, `password`, `user_activation_code`, `status`) VALUES ('". $REGISTER_EMAIL ."', '". $REGISTER_USERNAME ."', '". $REGISTER_PASSWORD ."', '". $ACTIVATION_CODE ."', 'not verified') ";
                $RESULT = mysqli_query($CONN, $SQL);

                $_SESSION['process-type'] = "login";
                $_SESSION['alert-type'] = "warning";
                $_SESSION['message'] = "Please visit your email to activate your account.";
            }

            else
            {
                $_SESSION['process-type'] = "register";
                $_SESSION['alert-type'] = "error";
                $_SESSION['message'] = "There is an error in processing your account. Please try again later.";
            }
        }
    }

    /* Forgot Password */

    if (isset($_POST['forgot_password']))
    {
        $FORGOT_EMAIL = $_POST['forgot_email'];

        $SQL = "SELECT * FROM `users` WHERE `email`='". $FORGOT_EMAIL ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
            while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            {
                $FORGOT_USERNAME = $USER_DETAILS['username'];
                $FORGOT_PASSWORD = $USER_DETAILS['password'];
                $FORGOT_STATUS = $USER_DETAILS['status'];
            }

            if ($FORGOT_STATUS == 'verified')
            {
                $MAIL->Subject = 'Retrieve Account';
                $MAIL->Body = '<p>Here are your login credentials. Please keep this confidential to yourself to avoid being hacked!</p><br><b>Username:</b> '. $FORGOT_USERNAME .'<br><b>Password:</b> '. $FORGOT_PASSWORD .'';
                $MAIL->AddAddress($FORGOT_EMAIL);

                if ($MAIL->Send())
                {
                    $_SESSION['process-type'] = "login";
                    $_SESSION['alert-type'] = "success";
                    $_SESSION['message'] = "Account retrieval success. Please visit your email account.";
                }

                else
                {
                    $_SESSION['process-type'] = "forgot";
                    $_SESSION['alert-type'] = "error";
                    $_SESSION['message'] = "There is an error in retrieving your account. Please try again later.";
                }
            }

            else
            {
                $_SESSION['process-type'] = "forgot";
                $_SESSION['alert-type'] = "error";
                $_SESSION['message'] = "This account is not yet verified.";
            }
        }

        else
        {
            $_SESSION['process-type'] = "forgot";
            $_SESSION['alert-type'] = "error";
            $_SESSION['message'] = "Email account is not registered.";
        }
    }

    /* Update */

    if (isset($_POST['update']))
    {
        $UPDATE_EMAIL = $_POST['update_email'];
        $UPDATE_USERNAME = $_POST['update_username'];
        $UPDATE_PASSWORD = $_POST['update_password'];
        
        $IS_USERNAME_VALID = TRUE;
        $IS_EMAIL_VALID = TRUE;

        $SQL = "SELECT * FROM `users` WHERE `username`='". $UPDATE_USERNAME ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
            $SQL = "SELECT * FROM `users` WHERE `id`='". $_SESSION['login_id'] ."' ";
            $RESULT = mysqli_query($CONN, $SQL);

            while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            {
                $OLD_USERNAME = $USER_DETAILS['username'];
                $OLD_PASSWORD = $USER_DETAILS['password'];
            }

            if ($OLD_USERNAME == $UPDATE_USERNAME)
            {
                $IS_USERNAME_VALID = TRUE;
            }

            else
            {
                $_SESSION['process-type'] = "register";  
                $_SESSION['alert-type'] = "error";
                $_SESSION['message'] = "Username already exists!";

                $IS_USERNAME_VALID = FALSE;
            }
        }

        else
        {
            $OLD_USERNAME = "";
            $OLD_PASSWORD = "";
        }

        $SQL = "SELECT * FROM `users` WHERE `email`='". $UPDATE_EMAIL ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
            $SQL = "SELECT * FROM `users` WHERE `id`='". $_SESSION['login_id'] ."' ";
            $RESULT = mysqli_query($CONN, $SQL);
            
            while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            {
                $OLD_EMAIL = $USER_DETAILS['email'];
            }

            if ($OLD_EMAIL == $UPDATE_EMAIL)
            {
                $IS_EMAIL_VALID = TRUE;
            }

            else
            {
                $_SESSION['process-type'] = "register";
                $_SESSION['alert-type'] = "error";
                $_SESSION['message'] = "Email already exists!";

                $IS_EMAIL_VALID = FALSE;
            }
        }

        else
        {
            $OLD_EMAIL = "";
        }

        if ($IS_EMAIL_VALID == TRUE and $IS_USERNAME_VALID == TRUE)
        {
            if ($OLD_EMAIL == $UPDATE_EMAIL and $OLD_USERNAME == $UPDATE_USERNAME and $OLD_PASSWORD == $UPDATE_PASSWORD)
            {
                $_SESSION['alert-type'] = "warning";
                $_SESSION['message'] = "There are no changes has been made.";
            }

            else
            {
                if ($OLD_EMAIL == $UPDATE_EMAIL)
                {
                    $MAIL_BODY = "
            
                        <p>Hi ".$UPDATE_USERNAME.",</p>
                        <p>Your account details has been updated. If you did this, ignore this message.</p>
                        <p>Best Regards,<br>Urban Gear</p>";

                    $MAIL->Subject = 'Update Account';
                    $MAIL->Body = $MAIL_BODY;
                    $MAIL->AddAddress($UPDATE_EMAIL);
                    
                    if ($MAIL->Send())
                    {
                        $SQL = "UPDATE `users` SET `email` = '". $UPDATE_EMAIL ."', `username` = '". $UPDATE_USERNAME ."', `password` = '". $UPDATE_PASSWORD ."' WHERE `id` = '". $_SESSION['login_id'] ."' ";
                        $RESULT = mysqli_query($CONN, $SQL);

                        header('Location: logout.php');
                    }

                    else
                    {
                        $_SESSION['alert-type'] = "error";
                        $_SESSION['message'] = "There is an error in processing your request. Please try again later.";
                    }
                }

                else
                {
                    $ACTIVATION_CODE = md5(rand());
                    $MAIL_BODY = "
            
                        <p>Hi ".$UPDATE_USERNAME.",</p>
                        <p>Please Open this link to verify your new email address - ".$BASE_URL."account_verification.php?activation_code=".$ACTIVATION_CODE."
                        <p>Best Regards,<br>Urban Gear</p>";

                    $MAIL->Subject = 'Update Account';
                    $MAIL->Body = $MAIL_BODY;
                    $MAIL->AddAddress($UPDATE_EMAIL);
                    
                    if ($MAIL->Send())
                    {
                        $SQL = "UPDATE `users` SET `email` = '". $UPDATE_EMAIL ."', `username` = '". $UPDATE_USERNAME ."', `password` = '". $UPDATE_PASSWORD ."', `status` = 'not verified', `user_activation_code` = '". $ACTIVATION_CODE ."' WHERE `id` = '". $_SESSION['login_id'] ."' ";
                        $RESULT = mysqli_query($CONN, $SQL);

                        header('Location: logout.php');
                    }

                    else
                    {
                        $_SESSION['alert-type'] = "error";
                        $_SESSION['message'] = "There is an error in processing your request. Please try again later.";
                    }
                }
            }
        }
    }

    /* Contact */

    if (isset($_POST['contact']))
    {
        $CONTACT_EMAIL = $_POST['contact_email'];
        $CONTACT_USERNAME = $_POST['contact_username'];
        $CONTACT_MESSAGE = $_POST['contact_message'];
        
        $SQL = "INSERT INTO `messages` (`email`, `username`, `message`) VALUES ('". $CONTACT_EMAIL ."', '". $CONTACT_USERNAME ."', '". $CONTACT_MESSAGE ."')";
        $RESULT = mysqli_query($CONN, $SQL);

        $_SESSION['alert-type'] = "success";
        $_SESSION['message'] = "Thank you for messaging us.";
    }

    /* Add to Cart */

    if (isset($_POST['add_to_cart']))
    {
        $ADD_ITEM_NUMBER = $_POST['add_item_number'];
        $ADD_ITEM_SIZE = $_POST['add_item_size'];
        $ADD_ITEM_NAME = $_POST['add_item_name'];
        $ADD_ITEM_PRICE = $_POST['add_item_price'];

        $SQL = "SELECT * FROM `users` WHERE `id`='". $_SESSION['login_id'] ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
			while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            {
                $CURRENT_EMAIL = $USER_DETAILS['email'];
				$CURRENT_USERNAME = $USER_DETAILS['username'];
			}
		}
        
        $SQL = "INSERT INTO `cart` (`id`, `user_id`, `email`, `username`, `item_number`, `size`, `brand_name`, `price`) VALUES (NULL, '". $_SESSION['login_id'] ."', '". $CURRENT_EMAIL ."', '". $CURRENT_USERNAME ."', '". $ADD_ITEM_NUMBER ."', '". $ADD_ITEM_SIZE ."', '". $ADD_ITEM_NAME ."', '". $ADD_ITEM_PRICE ."')";
        $RESULT = mysqli_query($CONN, $SQL);

        $_SESSION['alert-type'] = "success";
        $_SESSION['message'] = $ADD_ITEM_NAME." has been added to the cart.";
    }

    /* Remove Item */

    if (isset($_POST['remove']))
    {
        $REMOVE_ITEM = $_POST['remove_item'];
        
        $SQL = "SELECT * FROM `cart` WHERE `id`='". $REMOVE_ITEM ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
			while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            {
                $ITEM = $USER_DETAILS['brand_name'];
			}
		}

        $SQL = "DELETE FROM `cart` WHERE `cart`.`id` = '". $REMOVE_ITEM ."' ";
        $RESULT = mysqli_query($CONN, $SQL); 

        $_SESSION['alert-type'] = "success";
        $_SESSION['message'] = $ITEM." has been removed.";
    }

    /* Store Temporary Data */
    if (isset($_POST['store_data_for_checkout']))
    {
        $_SESSION['name'] = $_POST['fullname'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['address'] = $_POST['address'];
        $_SESSION['city'] = $_POST['city'];
        $_SESSION['province'] = $_POST['province'];

        header("location: payment.php");
    }

    /* Billing */

    if (isset($_POST['checkout']))
    {
        $CARD_NUMBER = $_POST['card_number'];
        $EXPIRATION_DATE = $_POST['expiration_date'];
        $CVC = $_POST['cvc'];
        $CARD_OWNER = $_POST['card_owner'];

        $SQL = "SELECT * FROM `cards` WHERE `card_number` = '". $CARD_NUMBER ."' AND `expiration_date` = '". $EXPIRATION_DATE ."' AND `cvc_code` = '". $CVC ."' AND `card_owner` = '". $CARD_OWNER ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
            while ($CARD_DETAILS = mysqli_fetch_array($RESULT))
            {
                $CREDIT_VALUE = $CARD_DETAILS['credit_value'];
			}

            date_add($date,date_interval_create_from_date_string("2 days"));
        
            $FROM_THIS_DATE = date_format($date,"m-d-Y");
            
            date_add($date,date_interval_create_from_date_string("3 days"));

            $TO_THIS_DATE = date_format($date,"m-d-Y");

            $CHECKOUT_NAME = $_SESSION['name'];
            $CHECKOUT_EMAIL = $_SESSION['email'];
            $CHECKOUT_ADDRESS = $_SESSION['address'];
            $CHECKOUT_CITY = $_SESSION['city'];
            $CHECKOUT_PROVINCE = $_SESSION['province'];
            $CHECKOUT_ITEMS = $_SESSION['items'];
            $CHECKOUT_TOTAL = $_SESSION['total'];

            $MAIL_BODY = "
                
                <p>Hi ".$CHECKOUT_NAME.",</p>
                <p>Your order has been processed for delivery. Please check your email for more details on your order. Thank You!</p>
                <p>Your package is expected to be delivered from ". $FROM_THIS_DATE ." to ". $TO_THIS_DATE .".</p>
                <br><br>
                <p>Best Regards,<br>Urban Gear</p>";

            $MAIL->Subject = 'Purchase Order';
            $MAIL->Body = $MAIL_BODY;
            $MAIL->AddAddress($CHECKOUT_EMAIL);
                        
            if ($MAIL->Send())
            {
                $CREDIT_VALUE = $CREDIT_VALUE - $_SESSION['total'];

                $SQL = "INSERT INTO `orders` (`id`, `fullname`, `email`, `address`, `city`, `province`, `items`, `total`) VALUES (NULL, '". $CHECKOUT_NAME ."', '". $CHECKOUT_EMAIL ."', '". $CHECKOUT_ADDRESS ."', '". $CHECKOUT_CITY ."', '". $CHECKOUT_PROVINCE ."', '". $CHECKOUT_ITEMS ."', '". $CHECKOUT_TOTAL ."')";
                $RESULT = mysqli_query($CONN, $SQL);

                $SQL = "DELETE FROM `cart` WHERE `cart`.`email` = '". $CHECKOUT_EMAIL ."' ";
                $RESULT = mysqli_query($CONN, $SQL);

                $SQL = "UPDATE `cards` SET `credit_value`='". $CREDIT_VALUE ."' WHERE `card_number`='". $CARD_NUMBER ."' ";
                $RESULT = mysqli_query($CONN, $SQL);

                $_SESSION['alert-type'] = "success";
                $_SESSION['message'] = "Your order has been processed for delivery. Please check your email for more details on your order. Thank You!";

                unset($_SESSION['items']);
                unset($_SESSION['total']);
            }

            else
            {
                $_SESSION['alert-type'] = "error";
                $_SESSION['message'] = "There is an error in processing your request. Please try again later.";
            }
        }

        else
        {
            $_SESSION['alert-type'] = "error";
            $_SESSION['message'] = "Invalid Card Details";
        }
    }

    /* Check Balance */
    if (isset($_POST['check_balance']))
    {
        $CARD_NUMBER = $_POST['card_number'];
        $EXPIRATION_DATE = $_POST['expiration_date'];
        $CVC = $_POST['cvc'];
        $CARD_OWNER = $_POST['card_owner'];

        $SQL = "SELECT * FROM `cards` WHERE `card_number` = '". $CARD_NUMBER ."' AND `expiration_date` = '". $EXPIRATION_DATE ."' AND `cvc_code` = '". $CVC ."' AND `card_owner` = '". $CARD_OWNER ."' ";
        $RESULT = mysqli_query($CONN, $SQL);

        if (mysqli_num_rows($RESULT) > 0)
        {
            while ($CARD_DETAILS = mysqli_fetch_array($RESULT))
            {
                $CREDIT_VALUE = $CARD_DETAILS['credit_value'];
            }

            $_SESSION['current_balance'] = $CREDIT_VALUE;

            $_SESSION['alert-type'] = "success";
            $_SESSION['message'] = "Valid Card Details Found";
        }

        else
        {
            $_SESSION['alert-type'] = "error";
            $_SESSION['message'] = "Invalid Card Details";
        }
    }
?>